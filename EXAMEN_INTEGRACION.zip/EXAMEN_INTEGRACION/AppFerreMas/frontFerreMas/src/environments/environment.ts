export const environment = {
    apiBaseUr: 'http://localhost:5027',
    apiBoleta: 'http://localhost:5001/api/boleta'
};
