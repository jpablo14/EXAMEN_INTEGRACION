export class ResponseModel {
    statusCode: number = 0;
    message: string = "";
    data: any;
}