export class ClienteModel {
    id: number = 0;
    nombre: string = "";
    rut: string = "";
    direccion: string = "";
    correo: string = "";
}