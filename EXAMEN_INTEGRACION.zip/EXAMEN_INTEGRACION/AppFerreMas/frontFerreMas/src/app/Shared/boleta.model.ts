export class BoletaModel {
    id = 0;
    id_cliente = 0;
    nombre_cliente = "";
    direccion_cliente = "";
    id_producto= 0;
    cantidad = 0;
    precio = 0;
    total_venta = 0;
    tipo_entrega = 0
}
