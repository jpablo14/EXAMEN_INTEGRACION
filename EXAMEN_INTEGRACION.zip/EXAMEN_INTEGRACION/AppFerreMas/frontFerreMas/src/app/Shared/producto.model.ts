export class ProductoModel {
    id: number = 0;
    nombre: string = "";
    descripcion: string = "";
    precio: number = 0;
    cantidad: number = 0;
}